const modal = document.querySelector('[data-modal]');
const paymentType = document.querySelector('[data-payment-type]');
const copyButton = document.querySelector('[data-copy-account]');
const copyStatus = document.querySelector('[data-copy-status]');
const toast = document.querySelector('[data-toast]');
const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.site-nav');
const accountNumber = '0017402569';

async function submitToChurch(payload) {
  const response = await fetch('/api/submissions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const result = await response.json();
  if (!response.ok || !result.ok) throw new Error(result.message || 'Submission failed');
  return result;
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('is-visible');
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.remove('is-visible'), 2400);
}

function setModal(open, type = 'Offering') {
  modal.setAttribute('aria-hidden', String(!open));
  if (open) {
    paymentType.textContent = type.toUpperCase();
    copyStatus.textContent = 'Copy the account number, then complete your giving in your bank app.';
    document.body.style.overflow = 'hidden';
  } else {
    document.body.style.overflow = '';
  }
}

document.querySelectorAll('[data-give-type]').forEach((card) => {
  card.addEventListener('click', () => setModal(true, card.dataset.giveType));
});
document.querySelectorAll('[data-close-modal]').forEach((element) => element.addEventListener('click', () => setModal(false)));
document.addEventListener('keydown', (event) => { if (event.key === 'Escape') setModal(false); });

copyButton.addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(accountNumber);
  } catch {
    const input = document.createElement('input');
    input.value = accountNumber;
    document.body.appendChild(input);
    input.select();
    document.execCommand('copy');
    input.remove();
  }
  copyButton.innerHTML = 'Copied to clipboard <span>✓</span>';
  copyStatus.textContent = 'Account number copied. Open your bank app to complete your giving.';
  showToast('Account number copied');
  window.setTimeout(() => { copyButton.innerHTML = 'Copy Account Number <span>⧉</span>'; }, 2600);
});

menuToggle.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('is-open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
});
nav.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
  nav.classList.remove('is-open');
  menuToggle.setAttribute('aria-expanded', 'false');
}));

const prayerForm = document.querySelector('[data-prayer-form]');
const prayerSuccess = document.querySelector('[data-prayer-success]');
const prayerStatus = document.querySelector('[data-prayer-status]');
prayerForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const request = new FormData(prayerForm).get('request').trim();
  if (!request) {
    prayerStatus.textContent = 'Please share what you would like us to pray about.';
    prayerStatus.className = 'form-status form-status--error';
    return;
  }
  const formData = new FormData(prayerForm);
  const submitButton = prayerForm.querySelector('button[type="submit"]');
  submitButton.disabled = true;
  submitButton.textContent = 'Sending...';
  try {
    await submitToChurch({ kind: 'Prayer Request', name: formData.get('name') || 'Anonymous', message: request });
    prayerForm.hidden = true;
    prayerSuccess.hidden = false;
    showToast('Prayer request sent');
  } catch (error) {
    prayerStatus.textContent = error.message || 'We could not send this request. Please try again.';
    prayerStatus.className = 'form-status form-status--error';
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = 'Send Prayer Request ↗';
  }
});
document.querySelector('[data-prayer-again]').addEventListener('click', () => {
  prayerForm.reset();
  prayerForm.hidden = false;
  prayerSuccess.hidden = true;
  prayerStatus.textContent = '';
});

const testimonyForm = document.querySelector('[data-testimony-form]');
const testimonyList = document.querySelector('[data-testimony-list]');
const testimonyEmpty = document.querySelector('[data-testimony-empty]');
const testimonyStatus = document.querySelector('[data-testimony-status]');
const savedTestimonies = JSON.parse(localStorage.getItem('holy-tabernacle-testimonies') || '[]');

function escapeHtml(value) {
  return value.replace(/[&<>'"]/g, (character) => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', "'":'&#39;', '"':'&quot;' }[character]));
}

function renderTestimony(testimony) {
  testimonyEmpty.hidden = true;
  const card = document.createElement('article');
  card.className = 'testimony-card reveal is-visible';
  card.innerHTML = `<span class="testimony-card__quote">“</span><h3>${escapeHtml(testimony.title)}</h3><p>${escapeHtml(testimony.story)}</p><footer><b>${escapeHtml(testimony.name)}</b><span>Shared with Holy Tabernacle Parish</span></footer>`;
  testimonyList.prepend(card);
}
savedTestimonies.forEach(renderTestimony);

testimonyForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const formData = new FormData(testimonyForm);
  const testimony = { name: formData.get('name').trim(), title: formData.get('title').trim(), story: formData.get('story').trim() };
  if (!testimony.name || !testimony.title || !testimony.story) {
    testimonyStatus.textContent = 'Please complete all testimony fields.';
    testimonyStatus.className = 'form-status form-status--error';
    return;
  }
  const submitButton = testimonyForm.querySelector('button[type="submit"]');
  submitButton.disabled = true;
  submitButton.textContent = 'Sending...';
  try {
    await submitToChurch({ kind: 'Testimony', name: testimony.name, title: testimony.title, message: testimony.story });
    savedTestimonies.unshift(testimony);
    localStorage.setItem('holy-tabernacle-testimonies', JSON.stringify(savedTestimonies.slice(0, 12)));
    renderTestimony(testimony);
    testimonyForm.reset();
    testimonyStatus.textContent = 'Your testimony was sent to the parish administration.';
    testimonyStatus.className = 'form-status form-status--success';
    showToast('Testimony sent');
  } catch (error) {
    testimonyStatus.textContent = error.message || 'We could not send this testimony. Please try again.';
    testimonyStatus.className = 'form-status form-status--error';
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = 'Share Testimony ↗';
  }
});

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('is-visible');
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
document.querySelectorAll('.reveal').forEach((element) => revealObserver.observe(element));
