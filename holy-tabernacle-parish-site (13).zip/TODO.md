# Holy Tabernacle Parish — Delivery Outcomes

## Church website
- [x] Create a modern, holy and responsive church website for HOLY TABERNACLE PARISH.
- [x] Use royal blue `#0a2a6b`, gold `#d4af37`, and white as the brand palette.
- [x] Add the approved temporary HTP monogram at the top left until the exact parish logo is available.

## Navigation and hero
- [x] Add header navigation for Home, About, Services, Prayer, Give, and Contact.
- [x] Add the requested hero message: “Welcome to Holy Tabernacle Parish - A Place of Worship, Word and Wonders.”
- [x] Add a “Give Online Now” button that scrolls to the Give section.

## About and service times
- [x] Add About Us content and the requested service times: Sunday 8AM–12PM, Wednesday Bible Study 5PM, Friday Prayer 5PM.

## Prayer requests and testimonies
- [x] Add a live prayer request form with name, request, privacy checkbox, required-field validation, and immediate confirmation state.
- [x] Add a testimony section with title, story, name, validation, and an on-page testimony feed.
- [x] Persist submitted testimonies locally in the visitor’s browser, limited to the latest 12 entries.
- [x] Keep prayer requests client-side/private until a church email or pastoral inbox endpoint is provided.

## Email integration
- [x] Add `POST /api/submissions` backend handling for prayer requests and testimonies.
- [x] Configure the recipient as `destinyosabohien18@gmail.com`.
- [x] Add Resend email delivery with environment-only `RESEND_API_KEY` and configurable sender.
- [x] Add clear client-side error states when delivery is not configured or fails.
- [ ] Add `RESEND_API_KEY` and a verified `RESEND_FROM_EMAIL` to the deployed server environment to activate live delivery.

## Giving flow
- [x] Add Give Offering, Give Tithe, and Give Sanctuary Offering cards.
- [x] Open a popup modal with the selected payment type and the shared Access Bank details.
- [x] Show account number `0017402569` in large bold text.
- [x] Add Copy Account Number behavior and a Proceed to Bank App action.
- [x] Use one account for all giving: Access Bank — Opara Festus ThankGod — 0017402569.

## Footer and verification
- [x] Add footer account details.
- [x] Verify the separate local preview at desktop and mobile sizes.
- [x] Verify static routes, JavaScript syntax, build output, and the email endpoint’s safe unconfigured response.
