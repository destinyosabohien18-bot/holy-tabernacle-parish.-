import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const port = Number(process.env.PORT || 3001);
const churchEmail = process.env.CHURCH_ADMIN_EMAIL || 'destinyosabohien18@gmail.com';
const resendFrom = process.env.RESEND_FROM_EMAIL || 'Holy Tabernacle Parish <onboarding@resend.dev>';
const mime = { '.html':'text/html; charset=utf-8', '.css':'text/css; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.json':'application/json; charset=utf-8', '.svg':'image/svg+xml', '.png':'image/png', '.jpg':'image/jpeg', '.webp':'image/webp' };

function sendJson(res, status, payload) {
  res.writeHead(status, { 'Content-Type':'application/json; charset=utf-8', 'Access-Control-Allow-Origin':'*' });
  res.end(JSON.stringify(payload));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk;
      if (body.length > 1_000_000) req.destroy(new Error('Request too large'));
    });
    req.on('end', () => resolve(body));
    req.on('error', reject);
  });
}

async function handleSubmission(req, res) {
  try {
    const payload = JSON.parse(await readBody(req));
    const kind = String(payload.kind || '').trim();
    const name = String(payload.name || 'Anonymous').trim().slice(0, 120);
    const message = String(payload.message || '').trim().slice(0, 5000);
    const title = String(payload.title || '').trim().slice(0, 160);
    if (!kind || !message) return sendJson(res, 400, { ok:false, message:'Please complete the required fields.' });
    if (!process.env.RESEND_API_KEY) return sendJson(res, 503, { ok:false, message:'Email delivery is not configured yet.' });

    const subject = title ? `[Holy Tabernacle] ${kind}: ${title}` : `[Holy Tabernacle] New ${kind}`;
    const text = `Holy Tabernacle Parish\n\nType: ${kind}\nName: ${name}\n${title ? `Title: ${title}\n` : ''}\n${message}`;
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type':'application/json' },
      body: JSON.stringify({ from: resendFrom, to: [churchEmail], subject, text })
    });
    if (!response.ok) return sendJson(res, 502, { ok:false, message:'The email service could not accept this submission.' });
    return sendJson(res, 200, { ok:true, message:'Submission sent to the parish administration.' });
  } catch {
    return sendJson(res, 400, { ok:false, message:'We could not read this submission. Please try again.' });
  }
}

http.createServer(async (req, res) => {
  const url = decodeURIComponent((req.url || '/').split('?')[0]);
  if (url === '/api/submissions' && req.method === 'POST') return handleSubmission(req, res);
  if (url === '/api/submissions' && req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin':'*', 'Access-Control-Allow-Methods':'POST, OPTIONS', 'Access-Control-Allow-Headers':'Content-Type' });
    return res.end();
  }
  const requested = url === '/' ? 'index.html' : url === '/logo.svg' || url === '/manus-routes.json' ? `public${url}` : url.startsWith('/public/') ? url.slice(1) : url;
  const file = path.normalize(path.join(root, requested));
  const safe = file.startsWith(root) ? file : path.join(root, 'index.html');
  fs.readFile(safe, (error, data) => {
    if (error) {
      fs.readFile(path.join(root, 'index.html'), (fallbackError, fallbackData) => {
        if (fallbackError) { res.writeHead(500); res.end('Server error'); return; }
        res.writeHead(200, { 'Content-Type': mime['.html'] });
        res.end(fallbackData);
      });
      return;
    }
    res.writeHead(200, { 'Content-Type': mime[path.extname(safe).toLowerCase()] || 'application/octet-stream', 'Cache-Control':'no-cache' });
    res.end(data);
  });
}).listen(port, '0.0.0.0', () => console.log(`Holy Tabernacle Parish preview listening on http://0.0.0.0:${port}`));
